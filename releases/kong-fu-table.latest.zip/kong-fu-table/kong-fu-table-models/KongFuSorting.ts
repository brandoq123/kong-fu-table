﻿export class KongFuSorting {

    public enabled: boolean;


    constructor(enabled?: boolean) {
        this.enabled = enabled || false;
    }
}